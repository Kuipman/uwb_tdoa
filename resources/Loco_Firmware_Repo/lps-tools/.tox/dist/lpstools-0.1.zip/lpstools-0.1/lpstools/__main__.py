from lpstools.gui import main

# Running the gui by default.
if __name__ == '__main__':
    main()
